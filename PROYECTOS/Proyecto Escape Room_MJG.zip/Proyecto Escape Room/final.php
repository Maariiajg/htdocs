<?php
require_once 'funciones.php';

// Comprobamos que las tres pruebas se han marcado como correctas
if (!isset($_SESSION['prueba1_correcta']) || !$_SESSION['prueba1_correcta']
    || !isset($_SESSION['prueba2_correcta']) || !$_SESSION['prueba2_correcta']
    || !isset($_SESSION['prueba3_correcta']) || !$_SESSION['prueba3_correcta']) {
    header('Location: index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>¡Has resuelto el misterio! — Castillo de Luna</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <header>
        <h1>¡Has restaurado el pergamino!</h1>
    </header>

    <main>
        <p>
            Tras recordar la fundación de la fiesta principal del pueblo otro rayo atraviesa el cielo, las pizas del pergamino empiezan a flotar 
            y se juntan con un brillo impresionante, unos segundos despues y como por arte de magia la oscuridad desaparece, las calles del recinto ferial 
            se llenan de trajes de flamenca, claveles, caballos y esa alegria caracteristica de este pueblo. Con cierta calidez en el pecho sales del 
            recinto ferial dejando esa alegria a las espaldas y decides dar un paseo por las calles llenas ahora de luz y la alegria, la ermita 
            vuelve a estar llena de esas imagenes y flores para honrrarlas. Camino al castillo observas la vega, tierra de cultivos que esa tarde tiene un 
            brillo especial. Finalmentes llegas al catillo de la familia Luna, donde toda esta aventura empezó, miras hacia el muro de la primera inscripsión 
            y te alegra ver que cuenta la historia del castillo. Con una sonrisa pasa hasta el anochecer leyendo la esa inscripción para no permitir que la historia 
            vuelva a morir y paseando por sus jardines.
        </p>

        <div>
            <a href="index.php?reset=1" class="boton principales">Jugar de nuevo</a>
        </div>
    </main>
</body>
</html>
